package com.wissassblog.sudoku.constants;

public enum GameState {
    COMPLETE,
    ACTIVE,
    NEW
}
