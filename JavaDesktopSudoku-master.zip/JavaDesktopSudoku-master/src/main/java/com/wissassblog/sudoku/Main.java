package com.wissassblog.sudoku;


public class Main {
    public static void main(String[] args){
        SudokuApplication.main(new String[]{});
    }
}
